package game;

public class Suggestion {
	public Suggestion(Character charc, Room room, Weapon weapon, Player p){
		if (room == p.getRoom()){

		}
	}
}
