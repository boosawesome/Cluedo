package game;

public class Room {
	private String name;
	private Coordinate doorCoord;
	private Room stair;

	public Room(String name, Coordinate coord, Room stair) {
		this.name = name;
		this.doorCoord = coord;
		this.stair = stair;
	}

	public String getName(){
		return name;
	}

	public Coordinate getCoordinate() {
		return doorCoord;
	}

	public Room getStair() {
		return stair;
	}
}
