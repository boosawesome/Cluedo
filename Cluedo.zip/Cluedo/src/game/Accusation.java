package game;

public class Accusation {

}
