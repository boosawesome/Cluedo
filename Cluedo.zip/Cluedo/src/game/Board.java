package game;

import java.util.ArrayList;

public class Board {
	private ArrayList<Room> rooms = new ArrayList<Room>();

	public Board(){

	}
}
