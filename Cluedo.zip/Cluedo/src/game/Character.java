package game;

public class Character {

}
